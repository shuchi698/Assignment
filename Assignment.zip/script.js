"use strict";

let cirlceNumber = document.getElementById("number");

cirlceNumber.addEventListener("click",function(){
    cirlceNumber.classList.add("circleClick");
})